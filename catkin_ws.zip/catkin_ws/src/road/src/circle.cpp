#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>

// Main moveit libraries are included

int main(int argc, char **argv)
{
	ros::init(argc, argv, "square");
	ros::NodeHandle node_handle;
	ros::AsyncSpinner spinner(0);

	spinner.start(); // For moveit implementation we need AsyncSpinner, we cant use ros::spinOnce()

	static const std::string PLANNING_GROUP = "moveit_zhanat_nurlan";

	moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP); // loading move_group

	const robot_state::JointModelGroup *joint_model_group = move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP); //For joint control

	geometry_msgs::PoseStamped current_pose;
	current_pose = move_group.getCurrentPose();

	ros::Rate loop_rate(50); //Frequency

	int steps = 18;
	float centerX = 2.5;
	float centerY = 0.5;
	float theta = 2 * 3.1416 / steps;

	while (ros::ok()){
		for (int i = 0; i < steps; i++) {
			geometry_msgs::PoseStamped target_pose = move_group.getCurrentPose();
			target_pose.pose.position.x = centerX + sin(theta * i) / 2;
			target_pose.pose.position.y = centerY + cos(theta * i) / 2;

			// Move to the position i
			while (ros::ok()){
				move_group.setApproximateJointValueTarget(target_pose); // To calculate the trajectory
				move_group.move();

				current_pose = move_group.getCurrentPose();
				if (abs(current_pose.pose.position.x - target_pose.pose.position.x) < 0.08 && abs(current_pose.pose.position.y - target_pose.pose.position.y) < 0.08){
					break; // Basically, check if we reached the desired position
				}
				loop_rate.sleep();
			}
		}
		
	}

	ROS_INFO("Done");
	ros::shutdown();
	return 0;
}
